﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Produtos;

namespace TelasTCC
{
    public partial class frmCadProdutos : Form
    {
        public frmCadProdutos()
        {
            InitializeComponent();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            ProdutosDTO dto = new ProdutosDTO();
            if (txtNome.Text!=null&&txtDescricao.Text!=null&&txtValor.Text!=null) { 
            

            dto.Nome = txtNome.Text;
            dto.Valor = txtValor.Text;
            dto.Descricao = txtDescricao.Text;
           

            MessageBox.Show("Produto cadastrado.");
                this.Close();
        }
            else
            {
                MessageBox.Show("Não foi possivel");
                txtNome.Text = "";
                txtDescricao.Text = "";
                txtValor.Text = "";
                txtDescricao.Focus();
                txtValor.Focus();
                txtNome.Focus();
            }
    ProdutosBusiness business = new ProdutosBusiness();
            business.Salvar(dto);
        }
    }
}
