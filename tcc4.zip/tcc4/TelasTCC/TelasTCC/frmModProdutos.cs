﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Produtos;

namespace TelasTCC
{
    public partial class frmModProdutos : Form
    {
        public frmModProdutos()
        {
            InitializeComponent();
            this.Height = 488;
            this.Width = 468;
            Listar();
        }



       

        private void btnConcluir_Click(object sender, EventArgs e)
        {
            ProdutosDTO dto = new ProdutosDTO();
            if (txtNome.Text != null && txtDescricao.Text != null && txtValor.Text != null)
            {
                dto.IdProduto = lblId.Text;
                dto.Nome = txtNome.Text;
                dto.Valor = txtValor.Text;
                dto.Descricao = txtDescricao.Text;

                ProdutosBusiness busines = new ProdutosBusiness();
                busines.Alterar(dto);

                if (MessageBox.Show("Produto Alterado.") == DialogResult.OK) {

                    ProdutosBusiness business = new ProdutosBusiness();
                    List<ProdutosDTO> lista = business.Listarprodutos();

                    dgvProdutos.AutoGenerateColumns = false;
                    dgvProdutos.DataSource = lista;
                }
                this.Height = 488;
                this.Width = 468;
                Listar();
            }
            else
            {
                MessageBox.Show("Não foi possivel");
                txtNome.Text = "";
                txtDescricao.Text = "";
                txtValor.Text = "";
                txtDescricao.Focus();
                txtValor.Focus();
                txtNome.Focus();
            }
            Listar();
        }

        public void Listar()
        {
            ProdutosBusiness business = new ProdutosBusiness();
            List<ProdutosDTO> Listarpro = business.Listarprodutos();

            dgvProdutos.AutoGenerateColumns = false;
            dgvProdutos.DataSource = Listarpro;
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Apagar " + this.dgvProdutos.CurrentRow.Cells[1].Value.ToString(), "Apagar item", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
            {
                ProdutosBusiness business = new ProdutosBusiness();
                business.Excluir(this.dgvProdutos.CurrentRow.Cells[0].Value.ToString());
                Listar();
            }
        }

        private void btnAdicionar_Click_1(object sender, EventArgs e)
        {
            frmCadProdutos cp = new frmCadProdutos();
            cp.Show();
        }
        


        private void btnAlterar_Click(object sender, EventArgs e)
        {


            ProdutosDTO dto = new ProdutosDTO();
            

            if (dgvProdutos.SelectedRows != null)
            {
                this.Height = 488;
                this.Width = 824;
                lblId.Text = this.dgvProdutos.CurrentRow.Cells[0].Value.ToString();
                txtNome.Text = this.dgvProdutos.CurrentRow.Cells[1].Value.ToString();
                txtDescricao.Text = this.dgvProdutos.CurrentRow.Cells[2].Value.ToString();
                txtValor.Text = this.dgvProdutos.CurrentRow.Cells[3].Value.ToString();
                Listar();
            }
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            Listar();
        }
    }
}
