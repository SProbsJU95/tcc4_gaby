﻿namespace TelasTCC
{
    partial class frmModFinanceiro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPeriodo = new System.Windows.Forms.Button();
            this.gbCaixa = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radAno = new System.Windows.Forms.RadioButton();
            this.radMes = new System.Windows.Forms.RadioButton();
            this.radDia = new System.Windows.Forms.RadioButton();
            this.lblRecCartao = new System.Windows.Forms.Label();
            this.lblRecDinheiro = new System.Windows.Forms.Label();
            this.lblDinheiro = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblCartao = new System.Windows.Forms.Label();
            this.dgvPagamento = new System.Windows.Forms.DataGridView();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gbCaixa.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPagamento)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnPeriodo
            // 
            this.btnPeriodo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPeriodo.Location = new System.Drawing.Point(342, 215);
            this.btnPeriodo.Name = "btnPeriodo";
            this.btnPeriodo.Size = new System.Drawing.Size(183, 45);
            this.btnPeriodo.TabIndex = 1;
            this.btnPeriodo.Text = "Vendas do período";
            this.btnPeriodo.UseVisualStyleBackColor = true;
            this.btnPeriodo.Click += new System.EventHandler(this.btnPeriodo_Click);
            // 
            // gbCaixa
            // 
            this.gbCaixa.Controls.Add(this.groupBox2);
            this.gbCaixa.Controls.Add(this.btnPeriodo);
            this.gbCaixa.Controls.Add(this.lblRecCartao);
            this.gbCaixa.Controls.Add(this.lblRecDinheiro);
            this.gbCaixa.Controls.Add(this.lblDinheiro);
            this.gbCaixa.Controls.Add(this.lblTotal);
            this.gbCaixa.Controls.Add(this.lblCartao);
            this.gbCaixa.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbCaixa.Location = new System.Drawing.Point(21, 29);
            this.gbCaixa.Name = "gbCaixa";
            this.gbCaixa.Size = new System.Drawing.Size(551, 268);
            this.gbCaixa.TabIndex = 0;
            this.gbCaixa.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radAno);
            this.groupBox2.Controls.Add(this.radMes);
            this.groupBox2.Controls.Add(this.radDia);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(33, 204);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(219, 56);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Período";
            // 
            // radAno
            // 
            this.radAno.AutoSize = true;
            this.radAno.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.radAno.Location = new System.Drawing.Point(148, 24);
            this.radAno.Name = "radAno";
            this.radAno.Size = new System.Drawing.Size(56, 24);
            this.radAno.TabIndex = 2;
            this.radAno.TabStop = true;
            this.radAno.Text = "Ano";
            this.radAno.UseVisualStyleBackColor = true;
            // 
            // radMes
            // 
            this.radMes.AutoSize = true;
            this.radMes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.radMes.Location = new System.Drawing.Point(85, 24);
            this.radMes.Name = "radMes";
            this.radMes.Size = new System.Drawing.Size(57, 24);
            this.radMes.TabIndex = 1;
            this.radMes.TabStop = true;
            this.radMes.Text = "Mês";
            this.radMes.UseVisualStyleBackColor = true;
            // 
            // radDia
            // 
            this.radDia.AutoSize = true;
            this.radDia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.radDia.Location = new System.Drawing.Point(27, 24);
            this.radDia.Name = "radDia";
            this.radDia.Size = new System.Drawing.Size(51, 24);
            this.radDia.TabIndex = 0;
            this.radDia.TabStop = true;
            this.radDia.Text = "Dia";
            this.radDia.UseVisualStyleBackColor = true;
            // 
            // lblRecCartao
            // 
            this.lblRecCartao.AutoSize = true;
            this.lblRecCartao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblRecCartao.Location = new System.Drawing.Point(29, 55);
            this.lblRecCartao.Name = "lblRecCartao";
            this.lblRecCartao.Size = new System.Drawing.Size(474, 20);
            this.lblRecCartao.TabIndex = 10;
            this.lblRecCartao.Text = "Recebido em cartão:   (VALOR TOTAL RECEBIDO EM CARTÃO)";
            // 
            // lblRecDinheiro
            // 
            this.lblRecDinheiro.AutoSize = true;
            this.lblRecDinheiro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblRecDinheiro.Location = new System.Drawing.Point(29, 113);
            this.lblRecDinheiro.Name = "lblRecDinheiro";
            this.lblRecDinheiro.Size = new System.Drawing.Size(491, 20);
            this.lblRecDinheiro.TabIndex = 9;
            this.lblRecDinheiro.Text = "Recebido em dinheiro: (VALOR TOTAL RECEBIDO EM DINHEIRO)";
            // 
            // lblDinheiro
            // 
            this.lblDinheiro.AutoSize = true;
            this.lblDinheiro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblDinheiro.Location = new System.Drawing.Point(29, 84);
            this.lblDinheiro.Name = "lblDinheiro";
            this.lblDinheiro.Size = new System.Drawing.Size(496, 20);
            this.lblDinheiro.TabIndex = 7;
            this.lblDinheiro.Text = "Vendas em dinheiro:    (QUANTIDADE DE VENDAS EM DINHEIRO)";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblTotal.Location = new System.Drawing.Point(29, 162);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(461, 20);
            this.lblTotal.TabIndex = 6;
            this.lblTotal.Text = "Total de vendas:           (DO DIA / DO MÊS / DO ANO) + (TOTAL)";
            // 
            // lblCartao
            // 
            this.lblCartao.AutoSize = true;
            this.lblCartao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblCartao.Location = new System.Drawing.Point(29, 25);
            this.lblCartao.Name = "lblCartao";
            this.lblCartao.Size = new System.Drawing.Size(479, 20);
            this.lblCartao.TabIndex = 1;
            this.lblCartao.Text = "Vendas em cartão:      (QUANTIDADE DE VENDAS EM CARTÃO)";
            // 
            // dgvPagamento
            // 
            this.dgvPagamento.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPagamento.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column5,
            this.Column1,
            this.Column2,
            this.Column4,
            this.Column3});
            this.dgvPagamento.Enabled = false;
            this.dgvPagamento.Location = new System.Drawing.Point(10, 37);
            this.dgvPagamento.Name = "dgvPagamento";
            this.dgvPagamento.Size = new System.Drawing.Size(531, 166);
            this.dgvPagamento.TabIndex = 4;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "Id";
            this.Column5.HeaderText = "id";
            this.Column5.Name = "Column5";
            this.Column5.Visible = false;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "Nome";
            this.Column1.FillWeight = 269.0722F;
            this.Column1.HeaderText = "Nome";
            this.Column1.Name = "Column1";
            this.Column1.Width = 170;
            // 
            // Column2
            // 
            this.Column2.FillWeight = 170F;
            this.Column2.HeaderText = "Desconto";
            this.Column2.Name = "Column2";
            this.Column2.Width = 150;
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column4.DataPropertyName = "Salario";
            this.Column4.FillWeight = 15.46391F;
            this.Column4.HeaderText = "Salário Bruto";
            this.Column4.Name = "Column4";
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column3.FillWeight = 15.46391F;
            this.Column3.HeaderText = "Salário Líquido";
            this.Column3.Name = "Column3";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.dgvPagamento);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.groupBox3.Location = new System.Drawing.Point(21, 303);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(551, 216);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(203, 24);
            this.label1.TabIndex = 5;
            this.label1.Text = "Folha de pagamento";
            // 
            // frmModFinanceiro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(593, 540);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.gbCaixa);
            this.Name = "frmModFinanceiro";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Módulo financeiro";
            this.gbCaixa.ResumeLayout(false);
            this.gbCaixa.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPagamento)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox gbCaixa;
        private System.Windows.Forms.Label lblCartao;
        private System.Windows.Forms.Label lblRecDinheiro;
        private System.Windows.Forms.Label lblDinheiro;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.DataGridView dgvPagamento;
        private System.Windows.Forms.Label lblRecCartao;
        private System.Windows.Forms.Button btnPeriodo;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton radAno;
        private System.Windows.Forms.RadioButton radMes;
        private System.Windows.Forms.RadioButton radDia;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.Label label1;
    }
}