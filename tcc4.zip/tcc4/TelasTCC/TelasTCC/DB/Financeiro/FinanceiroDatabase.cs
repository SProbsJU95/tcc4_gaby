﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TelasTCC.DB.Base;

namespace TelasTCC.DB.Financeiro
{
    class FinanceiroDatabase
    {
        public List<FinanceiroDTO> Listar()
        {
            string script = "SELECT `CPF`,`nome`,`salario` FROM funcionario";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<FinanceiroDTO> lista = new List<FinanceiroDTO>();

            while (reader.Read())
            {
                FinanceiroDTO dto = new FinanceiroDTO();
                dto.Id = reader.GetString("CPF");
                dto.Nome = reader.GetString("nome");
                dto.Salario = reader.GetString("salario");

                lista.Add(dto);
            }
            reader.Close();

            return lista;
        }

        public string ListarDataAtual(string data)
        {
            string script = data;

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<FinanceiroDTO> listaSenha = new List<FinanceiroDTO>();

            string agora = "";

            while (reader.Read())
            {
                FinanceiroDTO dto = new FinanceiroDTO();
                dto.Data = reader.GetString("agora");

                agora = dto.Data;
            }
            reader.Close();

            return agora;
        }

        public string ListarTotalVendas(string data)
        {
            string script = data;

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<FinanceiroDTO> listaSenha = new List<FinanceiroDTO>();

            string cartao = "";

            while (reader.Read())
            {
                FinanceiroDTO dto = new FinanceiroDTO();
                dto.TotalVendas = reader.GetString("qtdeVendas");

                cartao = dto.TotalVendas;
            }
            reader.Close();
            
            return cartao;
        }
    }
}
