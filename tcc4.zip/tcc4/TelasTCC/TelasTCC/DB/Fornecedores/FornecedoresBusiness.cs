﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TelasTCC.DB.Fornecedores
{
    class FornecedoresBusiness
    {
        public int Salvar(FornecedoresDTO dto)
        {
            if (dto.Nome == string.Empty)
                throw new ArgumentException("Nome é obrigatório.");

            if (dto.Fornecimento == string.Empty)
                throw new ArgumentException("Telefone é obrigatório.");

            if (dto.TipoProduto == string.Empty)
                throw new ArgumentException("Telefone é obrigatório.");

            if (dto.Cnpj == string.Empty)
                throw new ArgumentException("Telefone é obrigatório.");

            
            FornecedoresDatabase db = new FornecedoresDatabase();
            return db.Salvar(dto);
        }

        public List<FornecedoresDTO> Listar()
        {
            FornecedoresDatabase db = new FornecedoresDatabase();
            return db.Listar();
        }

        public int Atualizar(FornecedoresDTO dto)
        {
            if (dto.Nome == string.Empty)
                throw new ArgumentException("Nome é obrigatório.");

            if (dto.Fornecimento == string.Empty)
                throw new ArgumentException("Telefone é obrigatório.");

            if (dto.TipoProduto == string.Empty)
                throw new ArgumentException("Telefone é obrigatório.");

            if (dto.Cnpj == string.Empty)
                throw new ArgumentException("Telefone é obrigatório.");


            FornecedoresDatabase db = new FornecedoresDatabase();
            return db.Atualizar(dto);
        }
    }
}
