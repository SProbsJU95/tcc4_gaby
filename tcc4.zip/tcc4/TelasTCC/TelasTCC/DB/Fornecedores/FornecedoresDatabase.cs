﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Base;
using TelasTCC.DB.Endereco;

namespace TelasTCC.DB.Fornecedores
{
    class FornecedoresDatabase
    {
        public int Salvar(FornecedoresDTO dto)
        {
            string script = @"insert into fornecedor(cnpj,nome,fornecimento,tipo_produto,telefone_um,telefone_dois) values(@cnpj,@nome,@fornecimento,@tipo_produto,@telefone_um,@telefone_dois)";
            
            List<MySqlParameter> parms = new List<MySqlParameter>();
            
            parms.Add(new MySqlParameter("cnpj", dto.Cnpj));
            parms.Add(new MySqlParameter("nome", dto.Nome));
            parms.Add(new MySqlParameter("fornecimento", dto.Fornecimento));
            parms.Add(new MySqlParameter("tipo_produto", dto.TipoProduto));
            parms.Add(new MySqlParameter("telefone_um", dto.Telefone_um));
            parms.Add(new MySqlParameter("telefone_dois", dto.Telefone_dois));

            MessageBox.Show(script);

            Database db = new Database();
            return db.ExecuteInsetScriptWithPk(script, parms);
        }
        

        public List<FornecedoresDTO> Listar()
        {
            string script = "SELECT `nome`,CONCAT('Telefone1: ',`telefone_um`,' Telefone2: ',`telefone_dois`) as phone, CONCAT(`fornecimento`,' - ' ,`tipo_produto`) as foneciment, cnpj FROM `fornecedor`";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<FornecedoresDTO> lista = new List<FornecedoresDTO>();

            while (reader.Read())
            {
                FornecedoresDTO dto = new FornecedoresDTO();
                dto.Nome = reader.GetString("nome");
                dto.Telefone_um = reader.GetString("phone");
                dto.Fornecimento = reader.GetString("foneciment");
                dto.Cnpj = reader.GetString("cnpj");

                lista.Add(dto);
            }
            reader.Close();

            return lista;
        }

        public int Atualizar(FornecedoresDTO dto)
        {
            string script = @"update `fornecedor` set cnpj=@cnpj, nome=@nome, fornecimento=@fornecimento, tipo_produto=@tipo_produto, telefone_um=@telefone_um, telefone_dois=@telefone_dois where cnpj= '" + dto.Cnpj + " ';";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            parms.Add(new MySqlParameter("cnpj", dto.Cnpj));
            parms.Add(new MySqlParameter("nome", dto.Nome));
            parms.Add(new MySqlParameter("fornecimento", dto.Fornecimento));
            parms.Add(new MySqlParameter("tipo_produto", dto.TipoProduto));
            parms.Add(new MySqlParameter("telefone_um", dto.Telefone_um));
            parms.Add(new MySqlParameter("telefone_dois", dto.Telefone_dois));

            Database db = new Database();
            return db.ExecuteInsetScriptWithPk(script, parms);
        }
    }
}
