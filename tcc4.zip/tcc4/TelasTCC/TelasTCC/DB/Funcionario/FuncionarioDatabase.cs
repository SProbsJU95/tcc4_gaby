﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TelasTCC.DB.Base;

namespace TelasTCC.DB.Funcionario
{
    class FuncionarioDatabase
    {
        public List<FuncionarioDTO> Listar()
        {
            string script = "SELECT CPF, nome, salario, funcao, telefone, situacao FROM `funcionario` WHERE funcao != 'adm'";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<FuncionarioDTO> lista = new List<FuncionarioDTO>();

            while (reader.Read())
            {
                FuncionarioDTO dto = new FuncionarioDTO();
                dto.CPF = reader.GetString("CPF");
                dto.Nome = reader.GetString("nome");
                dto.Salario = reader.GetString("salario");
                dto.Funcao = reader.GetString("funcao");
                dto.Situacao = reader.GetString("situacao");
                dto.Telefone = reader.GetString("telefone");

                lista.Add(dto);
            }
            reader.Close();

            return lista;
        }

        public string ListarFuncionario(int i, string cpf)
        {
            string script = "SELECT f.CPF, f.data_de_nascimento, CONCAT(Rua,' - ', numero,' - ', Bairro) as Enderecos FROM `endereco` INNER JOIN `funcionario` as f WHERE f.Endereco_idEndereco = idEndereco and CPF = '"+cpf+"';";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<FuncionarioDTO> listaSenha = new List<FuncionarioDTO>();

            string campo = "";

            while (reader.Read())
            {
                FuncionarioDTO dto = new FuncionarioDTO();

                if (i == 0)
                {
                    dto.Campo = reader.GetString("CPF");
                }
                else if (i == 1)
                {
                    dto.Campo = reader.GetString("data_de_nascimento");
                }
                else if (i == 2)
                {
                    dto.Campo = reader.GetString("Enderecos");
                }

                campo = dto.Campo;
            }
            reader.Close();

            return campo;
        }
        public string Listar(string id, string campo)
        {
            string script = "select `" + campo + "`as campo from funcionario where CPF = '" + id + "';";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<FuncionarioDTO> listaSenha = new List<FuncionarioDTO>();

            string valor = "";

            while (reader.Read())
            {
                FuncionarioDTO dto = new FuncionarioDTO();
                dto.Campo = reader.GetString("campo");

                valor = dto.Campo;
            }
            reader.Close();

            return valor;
        }

        public string ListarEndereco(string id, string campo)
        {
            string script = "select `" + campo + "`as campo from endereco where idEndereco = '" + id + "';";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<FuncionarioDTO> listaSenha = new List<FuncionarioDTO>();

            string valor = "";

            while (reader.Read())
            {
                FuncionarioDTO dto = new FuncionarioDTO();
                dto.Campo = reader.GetString("campo");

                valor = dto.Campo;
            }
            reader.Close();

            return valor;
        }
    }
}
