﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelasTCC.DB.Funcionario
{
    class FuncionarioDTO
    {//nome, salario, funcao, situacao, telecone
        public string Nome { get; set; }
        public string Salario { get; set; }
        public string Funcao { get; set; }//checar utilidade
        public string Situacao { get; set; }
        public string Telefone { get; set; }
        public string CPF { get; set; }
        public string RG { get; set; }
        public string Nascimento { get; set; }
        public string Endereço { get; set; }
        public string Campo { get; set; }
    }
}
