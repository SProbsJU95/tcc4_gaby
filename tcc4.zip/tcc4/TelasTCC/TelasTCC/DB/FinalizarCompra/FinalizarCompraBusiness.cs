﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelasTCC.DB.FinalizarCompra
{
    class FinalizarCompraBusiness
    {
        public int SalvarComBandeira(FinalizarCompraDTO dto)
        {
            /*if (dto.Nome == string.Empty)
                throw new ArgumentException("Nome é obrigatório.");

            if (dto.Celular== string.Empty)
                throw new ArgumentException("Telefone é obrigatório.");

            if (dto.num_residencia == string.Empty)
                throw new ArgumentException("Número da residencia é obrigatório.");*/

            FinalizarCompraDatabase db = new FinalizarCompraDatabase();
            return db.SalvarComBandeira(dto);
        }
        public int SalvarSemBandeira(FinalizarCompraDTO dto)
        {
            /*if (dto.Nome == string.Empty)
                throw new ArgumentException("Nome é obrigatório.");

            if (dto.Celular== string.Empty)
                throw new ArgumentException("Telefone é obrigatório.");

            if (dto.num_residencia == string.Empty)
                throw new ArgumentException("Número da residencia é obrigatório.");*/

            FinalizarCompraDatabase db = new FinalizarCompraDatabase();
            return db.SalvarSemBandeira(dto);
        }
        public List<FinalizarCompraDTO> Listar(string idCompra)
        {
            FinalizarCompraDatabase db = new FinalizarCompraDatabase();
            return db.Listar(idCompra);
        }

        public int Excluir(string id)
        {
            /*if (dto.Nome == string.Empty)
                throw new ArgumentException("Nome é obrigatório.");

            if (dto.Celular== string.Empty)
                throw new ArgumentException("Telefone é obrigatório.");

            if (dto.num_residencia == string.Empty)
                throw new ArgumentException("Número da residencia é obrigatório.");*/

            FinalizarCompraDatabase db = new FinalizarCompraDatabase();
            return db.Excluir(id);
        }

        public int Editar(FinalizarCompraDTO dto)
        {
            /*if (dto.Nome == string.Empty)
                throw new ArgumentException("Nome é obrigatório.");

            if (dto.Celular== string.Empty)
                throw new ArgumentException("Telefone é obrigatório.");

            if (dto.num_residencia == string.Empty)
                throw new ArgumentException("Número da residencia é obrigatório.");*/

            FinalizarCompraDatabase db = new FinalizarCompraDatabase();
            return db.Editar(dto);// EDITARRR
        }

    }
}
