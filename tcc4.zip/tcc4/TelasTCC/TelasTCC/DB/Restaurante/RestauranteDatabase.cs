﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Base;

namespace TelasTCC.DB.Restaurante
{
    class RestauranteDatabase
    {
        public int Salvar(RestauranteDTO dto)
        {
            string script = @"INSERT INTO itenspedido(`qtdeProduto`,`Produto_IdProduto`,`valorItem`,`pedido`) VALUES(@qtdeProduto,@Produto_IdProduto,@valorItem,@pedido)";

            List<MySqlParameter> parms = new List<MySqlParameter>();
            parms.Add(new MySqlParameter("Produto_IdProduto", dto.IdProduto));
            parms.Add(new MySqlParameter("qtdeProduto", dto.QuantidadeProduto));
            parms.Add(new MySqlParameter("valorItem", float.Parse(dto.Preco) * float.Parse(dto.QuantidadeProduto)));
            parms.Add(new MySqlParameter("pedido", int.Parse(dto.idPedido) + 1));

            Database db = new Database();
            return db.ExecuteInsetScriptWithPk(script, parms);
        }
        
        public DataTable Listar(string tipo)
        {
            string script = "SELECT `nome` FROM `produto` WHERE `descricao` = '"+tipo+"';";

            Connection conn = new Connection();

            MySqlCommand com = new MySqlCommand();
            com.Connection = conn.Create();
            com.CommandText = script;

            MySqlDataReader reader = com.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(reader);
            
            return dataTable;
        }

        public DataTable ListarRefeicao()
        {
            string script = "SELECT `tamanho` FROM `tamanho` ;";

            Connection conn = new Connection();

            MySqlCommand com = new MySqlCommand();
            com.Connection = conn.Create();
            com.CommandText = script;

            MySqlDataReader reader = com.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(reader);

            return dataTable;
        }

        public string ListarProduto(string produto)
        {
            string script = "SELECT `idProduto` FROM `produto` WHERE `nome` = '"+ produto +"';";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<RestauranteDTO> listar = new List<RestauranteDTO>();

            string senha = "";

            while (reader.Read())
            {
                RestauranteDTO dto = new RestauranteDTO();
                dto.IdProduto = reader.GetString("idProduto");

                senha = dto.IdProduto;
            }
            reader.Close();

            return senha;
        }
        public string ListarValor(string valor)
        {
            string script = "SELECT `valor` FROM `produto` WHERE `nome` = '" + valor + "';";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<RestauranteDTO> listar = new List<RestauranteDTO>();

            string preco = "";

            while (reader.Read())
            {
                RestauranteDTO dto = new RestauranteDTO();
                dto.Preco = reader.GetString("valor");

                preco = dto.Preco;
            }
            reader.Close();

            return preco;
        }

        public string ListarPedido()
        {
            string script = "SELECT MAX(`idPedido`) AS id FROM pedido";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<RestauranteDTO> listar = new List<RestauranteDTO>();

            string idPedido = "";

            while (reader.Read())
            {
                RestauranteDTO dto = new RestauranteDTO();
                dto.idPedido = reader.GetString("id");

                idPedido = dto.idPedido;
            }
            reader.Close();

            return idPedido;
        }

        public string ListarValorFinal(string valFinal)
        {
            int final = int.Parse(valFinal) + 1;
            string script = "SELECT SUM(`valorItem`) as total FROM itenspedido WHERE `pedido` = '" + final + "';";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<RestauranteDTO> listar = new List<RestauranteDTO>();

            string valorFinal = "";

            while (reader.Read())
            {
                RestauranteDTO dto = new RestauranteDTO();
                dto.ValorFinal = reader.GetString("total");

                valorFinal = dto.ValorFinal;
            }
            reader.Close();

            return valorFinal;
        }

        public int FinalizarPedido(RestauranteDTO dto)
        {
            string script = @"INSERT INTO pedido(`valor_pedido`,`ItensPedido_pedido`,`TipoPedido_idTipodePedido`) VALUES(@valor_pedido,@ItensPedido_pedido,@TipoPedido_idTipodePedido)";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            parms.Add(new MySqlParameter("valor_pedido", float.Parse(dto.ValorFinal)));
            parms.Add(new MySqlParameter("ItensPedido_pedido", int.Parse(dto.idPedido) + 1));
            parms.Add(new MySqlParameter("TipoPedido_idTipodePedido", 1));

            Database db = new Database();
            return db.ExecuteInsetScriptWithPk(script, parms);
        }
    }
}
