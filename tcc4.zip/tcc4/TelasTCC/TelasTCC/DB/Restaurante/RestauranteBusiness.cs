﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelasTCC.DB.Restaurante
{
    class RestauranteBusiness
    {
        public int Salvar(RestauranteDTO dto)
        {
            /*if (dto.Produto == string.Empty)
                throw new ArgumentException("Bebida é obrigatório.");

            if (dto.QuantidadeProduto == string.Empty)
                throw new ArgumentException("Quantidade é obrigatória.");*/

            RestauranteDatabase db = new RestauranteDatabase();
            return db.Salvar(dto);
        }

        public DataTable ListarRefeicao()
        {
            RestauranteDatabase db = new RestauranteDatabase();
            return db.ListarRefeicao();
        }

        public DataTable Listar(string tipo)
        {
            RestauranteDatabase db = new RestauranteDatabase();
            return db.Listar(tipo);
        }

        public int SalvarPedido(RestauranteDTO dto)
        {
            RestauranteDatabase db = new RestauranteDatabase();
            return db.FinalizarPedido(dto);
        }
    }
}
