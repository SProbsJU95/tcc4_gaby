﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Base;

namespace TelasTCC.DB.Produtos
{
    class ProdutosBusiness
    {
        public int Salvar(ProdutosDTO dto)
        {
            if (dto.Nome == string.Empty)
                throw new ArgumentException("Nome é obrigatório.");

            if (dto.Valor == string.Empty)
                throw new ArgumentException("Valor é obrigatório.");

            if (dto.Descricao == string.Empty)
                throw new ArgumentException("Descrição é obrigatório.");



            ProdutosDatabase db = new ProdutosDatabase();
            return db.Salvar(dto);

        }

        public int Alterar(ProdutosDTO dto)
        {
            /*if (dto.Nome == string.Empty)
                throw new ArgumentException("Nome é obrigatório.");

            if (dto.Valor == string.Empty)
                throw new ArgumentException("Valor é obrigatório.");

            if (dto.Descricao == string.Empty)
                throw new ArgumentException("Descrição é obrigatório.");
          
    */

            ProdutosDatabase db = new ProdutosDatabase();
            return db.Alterar(dto);

        }


        public List<ProdutosDTO> Listarprodutos()
        {
            ProdutosDatabase db = new ProdutosDatabase();
            return db.Listarprodutos();
        }


        internal void Salvar(object dto)
        {
            throw new NotImplementedException();
        }


        public int Excluir(string id)
        {

            ProdutosDatabase db = new ProdutosDatabase();
            return db.Excluir(id);
        }
    }
}

